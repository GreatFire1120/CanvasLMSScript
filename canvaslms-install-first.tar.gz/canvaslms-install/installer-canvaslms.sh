#!/bin/bash

clear

CANVASUSER=canvasuser

POSTGRESUSER=canvas
POSTGRESPASSWD=infocenteros1120
DBNAME=canvas_production


LIBLTDL=lib.tar.gz
POSTGRESQLPKG=pgdg-redhat96-9.6-3.noarch
RUBYPKG=ruby-2.3.3.tar.gz
NODEPKG=node-v6.10.0.tar.gz

LIBLTDLPATH=/usr/lib64
POSTGRESQLDIR=/usr/pgsql-9.6
RUBYDIR=/opt/ruby-2.3.3
NODEDIR=/opt/node-v6.10.0
CANVASDIR=/var/rails/canvas
BUNDLEDIR=/usr/local/bin
PGDIR=/var/lib/pgsql/9.6
HTTPDIR=/etc/httpd/conf
PASSENGERDIR=/etc/httpd/conf.d

SOURCEDIR=/opt
TEMPDIR=$SOURCEDIR/temp
CURRENTPATH=$(pwd)


HTTPSPSQL=https://yum.postgresql.org/9.6/redhat/rhel-7-x86_64/pgdg-redhat96-9.6-3.noarch.rpm
HTTPRUBY=http://cache.ruby-lang.org/pub/ruby/2.3/ruby-2.3.3.tar.gz
HTTPSNODE=https://nodejs.org/download/release/v6.10.0/node-v6.10.0.tar.gz


echo -e
echo -e "\t******************************************************************"
echo -e "\t\tStart installing for Canvas LMS on CentOS Minimal 7"
echo -e "\t******************************************************************"
echo -e

############################### step 1: account permission #########################
echo -e
echo -e "\t************* Do you make running as root account? ***************"
sleep 3

if [ "$(id -u)" = "0" ]; then
	echo -e "\t\tOk! You are running as root."
else
	echo -e "\t\tSorry, you must run this script as root."
	exit 1
fi

echo -e "\t******************************************************************"
echo -e

if [[ -e $TEMPDIR ]]; then	# /opt/temp
	echo -n
else
	mkdir $TEMPDIR
fi
####################################################################################


############################# step 2: install library packages #####################
echo -e
echo -e "\t******************* Installing library files *********************"
echo -e
echo -e "\t***************** installing library packages ********************"
sleep 3

echo -e
if [[ -f $TEMPDIR/libpkg.confirm ]]; then
	echo -e "\t************ Already installed library packages. OK! *************"
else
	yum install -y mc wget \
		gcc-c++ patch \
		readline readline-devel \
		zlib zlib-devel \
		libyaml-devel libffi-devel openssl-devel \
		make bzip2 autoconf automake libtool \
		bison libxml2-devel libxslt-devel \
		git libcurl-devel m2crypto \
		httpd-devel sqlite-devel \
		xmlsec1-openssl xmlsec1-openssl-devel
	libpkg=$?
	if [[ $libpkg -eq 0 ]]; then
		echo -e "\t************* installing library packages. Success! *************"
		touch $TEMPDIR/libpkg.confirm
	else
		echo -e "\t** installing library packages, fialure. You must try it again. *"
		exit 1
	fi
fi

echo -e
echo -e "\t**************** installing library so files *********************"
sleep 3

echo -e
if [[ -f $TEMPDIR/libso.confirm ]]; then
	echo -e "\t ************ Already installed library so files. OK! *************"
else
	if [[ -f $LIBLTDL ]]; then
		cp $LIBLTDL $LIBLTDLPATH
		cd $LIBLTDLPATH
		tar xzvf $LIBLTDL
		rm -rf $LIBLTDL
		
		if [ -f libltdl.so ] && [ -f libltdl.so.3 ] && [ -f libltdl.so.3.1.0 ]; then
			echo -e "\t************* installing library so files. Success! *****************"
			touch $TEMPDIR/libso.confirm
		else
			echo -e "\t*** installing library so files, fialure. You must try it again. ****"
			exit 1
		fi
	else
		echo -e "\t*** no found library so files, fialure. You must try it again. **"
		exit 1
	fi
fi	

echo -e
echo -e "\t***************** Installing library files. Finished ****************"
echo -e
####################################################################################


####################### step 3: install postgresql package #########################
echo -e
echo -e "\t****************** Installing Postgresql package ********************"

cd $SOURCEDIR
# step 3-1: copy postgresql package
echo -e
echo -e "\t******************** getting postgresql package *********************"
sleep 3

echo -e
if [[ -f $TEMPDIR/psql1.confirm ]]; then
	echo -e "\t**************** Already got postgresql package. OK! ****************"
else
	if [[ -f $POSTGRESQLPKG.rpm.backup ]]; then
		rm -rf $POSTGRESQLPKG.rpm
		cp $POSTGRESQLPKG.rpm.backup $POSTGRESQLPKG.rpm
		echo -e "\t************* restoring postgresql from backup. Success! *************"
	else
		wget $HTTPSPSQL
		postgresqlok=$?
		if [[ $postgresqlok -eq 0 ]]; then
			cp $POSTGRESQLPKG.rpm $POSTGRESQLPKG.rpm.backup
			echo -e "\t*********** copying postgresql from repository. Success! ***********"
			touch $TEMPDIR/psql1.confirm
		else
			if [[ -f $POSTGRESQLPKG.rpm ]]; then
				rm -rf $POSTGRESQLPKG.rpm
			fi
		
			echo -e "\t** getting postgresql package, failure. You must try it again. ***"
			exit 1
		fi
	fi
fi

# step 3-2: install postgresql package
echo -e
echo -e "\t****************** installing postgresql package ********************"
sleep 3

echo -e
if [[ -f $TEMPDIR/psql2.confirm ]]; then
	echo -e "\t************ Already installed postgresql package. OK! **************"
else
	rpm -q $POSTGRESQLPKG &> /dev/null
	postgresqlok=$?
	if [[ $postgresqlok -eq 0 ]]; then
		echo -e "\t********** Already installed postgresql package. Success! ***********"
	else
		rpm -Uvh $POSTGRESQLPKG.rpm
		postgresqlok=$?
		if [[ $postgresqlok -eq 0 ]]; then
			echo -e "\t************ installing postgresql package. Success! *************"
			touch $TEMPDIR/psql2.confirm
		else
			echo -e "\t* installing postgresql package, failure. You must try it again. *"
			exit 1
		fi
	fi
fi

# step 3-3: install postgresql server
echo -e
echo -e "\t***************** installing postgresql server **********************"
sleep 3

echo -e
if [[ -f $TEMPDIR/psql3.confirm ]]; then
	echo -e "\t*********** Already installed postgresql server. OK! ****************"
else
	yum install -y postgresql96 postgresql96-server postgresql96-contrib postgresql96-libs
	serverok=$?
	if [[ $serverok -eq 0 ]]; then
		echo -e "\t************** installing postgresql server. Success! ***************"
		touch $TEMPDIR/psql3.confirm
	else
		echo -e "\t**** installing postgresql server, fialure. You must try it again. *****"
		exit 1
	fi
fi

# step 3-4: initialize postgresql database
echo -e
echo -e "\t***************** initializing postgresql database ******************"
sleep 3

echo -e
if [[ -f $TEMPDIR/psql4.confirm ]]; then
	echo -e "\t********** Already initializing postgresql database. OK! *************"
else
	$POSTGRESQLDIR/bin/postgresql96-setup initdb
	systemctl start postgresql-9.6
	systemctl enable postgresql-9.6
	
	touch $TEMPDIR/psql4.confirm
	echo -e "\t*********** initializing postgresql database. Success! ***************"
fi

# step 3-5: set postgresql database
echo -e
echo -e "\t********************* creating user for database ********************"
sleep 3

echo -e
if [[ -f $TEMPDIR/psql51.confirm ]]; then
	echo -e "\t********** Already created $POSTGRESUSER user for database. OK! *************"
else
	echo -n "Enter username for database(default name: $POSTGRESUSER): "
	read POSTGRESUSER
	
	echo -n "Enter $POSTGRESUSER's password: "
	read POSTGRESPASSWD
	
	echo -e
	echo -e "You must coordinate the password that you have just entered and the password that you will now enter."
	echo -e "Or you can't use Postgresql for Canvas LMS."
	echo -e
	
	sudo -u postgres createuser $POSTGRESUSER --no-createdb \
		--no-superuser --no-createrole --pwprompt
	sudo -u postgres createdb $DBNAME --owner=$POSTGRESUSER
	
	touch $TEMPDIR/psql51.confirm
	echo -e "\t*********** creating $POSTGRESUSER user for database. Success! ************"
fi

echo -e
echo -e "\t*************** altering $USER superuser for database *****************"

echo -e
if [[ -f $TEMPDIR/psql52.confirm ]]; then
	echo -e "\t********** Already altered $USER superuser for database. OK! **********"
else
	sudo -u postgres createuser $USER
	sudo -u postgres psql -c "alter user $USER with superuser" postgres
	
	touch $TEMPDIR/psql52.confirm
	echo -e "\t*********** altering $USER superuser for database. Success! **********"
fi

echo -e
echo -e "\t************* Installing Postgresql package. Finished ***************"
echo -e
####################################################################################


################################ step 4: install redis package #####################
echo -e
echo -e "\t********************* Installing redis package **********************"
sleep 3

echo -e
if [[ -f $TEMPDIR/redis.confirm ]]; then
	echo -e "\t*************** Already installed redis package. OK! *****************"
else
	yum install -y epel-release
	yum install -y redis
	redisok=$?
	if [[ $redisok -eq 0 ]]; then
		echo -e "\t***************** Installing redis package. Success! *****************"
		touch $TEMPDIR/redis.confirm
	else
		echo -e "\t***** Installing redis package, failure. You must try it again. ******"
		exit 1
	fi
fi

echo -e
echo -e "\t***************** Installing redis package. Finished *****************"
echo -e
####################################################################################


########################### Stage 5: install ruby package ##########################
echo -e
echo -e "\t********************** Installing ruby package ***********************"

# step 5-1: copy ruby package
echo -e
echo -e "\t********************** getting ruby package **************************"
sleep 3
cd $SOURCEDIR

echo -e
if [[ -f $TEMPDIR/ruby1.confirm ]]; then
	echo -e "\t******************** Already got ruby package. OK! *******************"
else
	if [[ -f $RUBYPKG.backup ]]; then
		rm -rf $RUBYPKG
		cp $RUBYPKG.backup $RUBYPKG
		echo -e "\t************* restoring ruby package from backup. Success! ***********"
	else
		curl -O $HTTPRUBY
		rubyok=$?
		if [[ $rubyok -eq 0 ]]; then
			cp $RUBYPKG $RUBYPKG.backup
			echo -e "\t**************** copying ruby package from repository ***************"
			touch $TEMPDIR/ruby1.confirm
		else
			if [[ -f $RUBYPKG ]]; then
				rm -rf $RUBYPKG
			fi
		
			echo -e "\t********* getting ruby package, failure. You must try it again. *********"
			exit 1
		fi
	fi
fi

# step 5-2: install ruby package
echo -e
echo -e "\t********************* installing ruby package ************************"
sleep 3

echo -e
if [[ -f $TEMPDIR/ruby2.confirm ]]; then
	echo -e "\t****************** Already installed ruby package ********************"
else
	tar xzvf $RUBYPKG
	cd $RUBYDIR
	./configure
	make
	make install
	
	touch $TEMPDIR/ruby2.confirm
	echo -e "\t******************** installing ruby package. Success! ****************"
fi

echo -e
echo -e "\t**************** Installing ruby package. Finished *******************"
echo -e
####################################################################################


########################## step 6: install canvas lms ##############################
echo -e
echo -e "\t*************** Creating canvasuser for canvas lms *******************"
sleep 3

# step 6-1: create canvas user
echo -e
echo -e "\t********************** createing canvas user **************************"

echo -e
if [[ -f $TEMPDIR/adduser.confirm ]]; then
	echo -e "\t***************** Already created canvas user. OK! ********************"
else
	adduser $CANVASUSER
	passwd $CANVASUSER
	
	touch $TEMPDIR/adduser.confirm
	echo -e "\t**************** creating canvas user. Success! ***********************"
fi

# step 6-2: install canvas lms
echo -e
echo -e "\t********************* Installing Canvas LMS **************************"
sleep 3

echo -e
cd /var
if [[ -e rails/ ]]; then
	echo -n
else
	mkdir rails
fi

cd rails
if [[ -f $TEMPDIR/canvas.confirm ]]; then
	echo -e "\t************** Already installed Canvas LMS. OK! *********************"
else
	git clone https://github.com/instructure/canvas-lms.git canvas
	canvasok=$?
	if [[ $canvasok -eq 0 ]]; then
		chown -R $CANVASUSER:$CANVASUSER $CANVASDIR
		echo -e "\t******************** Installing Canvas LMS. Success! *****************"
		touch $TEMPDIR/canvas.confirm
	else
		rm -rf $CANVASDIR
		echo -e "\t********** Installing Canvas LMS, failure. You must try it! **********"
		exit 1
	fi
fi

echo -e
echo -e "\t***************** Installing Canvas LMS. Finished ********************"
echo -e
####################################################################################


############################ step 7: install node package ##########################
echo -e
echo -e "\t********************** Installing node package ***********************"

# step 7-1: copy node package
echo -e
echo -e "\t********************** getting node package **************************"
sleep 3

echo -e
cd $SOURCEDIR
if [[ -f $TEMPDIR/node1.confirm ]]; then
	echo -e "\t****************** Already got node package. OK! ********************"
else
	if [[ -f $NODEPKG.backup ]]; then
		rm -rf $NODEPKG
		cp $NODEPKG.backup $NODEPKG
		echo -e "\t************* restoring node package from backup. Success! ***********"
	else
		wget $HTTPSNODE
		nodeok=$?
		if [[ $nodeok -eq 0 ]]; then
			cp $NODEPKG $NODEPKG.backup
			echo -e "\t************ copying node package from repository. Success! *************"
			touch $TEPMDIR/node1.confirm
		else
			if [[ -f $NODEPKG ]]; then
				rm -rf $NODEPKG
			fi
		
			echo -e "\t********* getting node package, failure. You must try it again. *********"
			exit 1
		fi
	fi
fi

# step 7-2: install node package
echo -e
echo -e "\t********************* installing node package ************************"
sleep 3

echo -e
if [[ -f $TEMPDIR/node2.confirm ]]; then
	echo -e "\t**************** Already installed node package. OK! *****************"
else
	tar xzvf $NODEPKG
	cd $NODEDIR
	./configure
	make
	make install
	
	cp -rf /usr/local/bin/node /usr/bin/node	# for version coordination
	touch $TEMPDIR/node2.confirm
	echo -e "\t***************** installing node package. Success! *******************"
fi

echo -e
echo -e "\t**************** Installing node package. Finished *******************"
echo -e
####################################################################################


############################## step 8: install npm package #########################
echo -e
echo -e "\t********************** Installing npm package ************************"
sleep 3

echo -e
if [[ -f $TEMPDIR/npmpkg.confirm ]]; then
	echo -e "\t***************** Already installed npm package. OK! *****************"
else
	yum install -y npm
	npmok=$?
	if [[ $rnpmok -eq 0 ]]; then
		echo -e "\t****************** Installing npm package. Success! ******************"
		touch $TEMPDIR/npmpkg.confirm
	else
		echo -e "\t****** Installing npm package, failure. You must try it again. *******"
		exit 1
	fi
fi

echo -e
echo -e "\t***************** Installing npm package. Finished *******************"
echo -e
####################################################################################


########################### step 9: install bundle #################################
echo -e
echo -e "\t******************** Installing bundle *******************************"
sleep 3

# step 9-1: installing bundle
echo -e "\t************************ installing bundler **************************"

echo -e
if [[ -e $TEMPDIR/bundle.confirm ]]; then
	echo -e "\t***************** Already installed bundler. OK! **********************"
else
	gem install bundler -v 1.13.6

	cd $CANVASDIR
	sudo -u $CANVASUSER $BUNDLEDIR/bundle install --path vendor/bundle
	bundleok=$?
	if [[ $bundleok -eq 0 ]]; then
		echo -e "\t***************** Installing bundler. Success! ***********************"
		touch $TEMPDIR/bundle.confirm
	else
		echo -e "\t******** Installing bundler, failure. You must try it again. *********"
		exit 1
	fi
fi

# step 9-2: adding necessary files
echo -e
echo -e "\t******************* adding necessary files ***************************"
sleep 3

echo -e
cd $CANVASDIR
if [[ -f $TEMPDIR/files.confirm ]]; then
	echo -e "\t******************* Already added necessary files. OK! ***************"
else
	for config in amazon_s3 database \
		delayed_jobs domain file_store outgoing_mail security external_migration; \
		do cp config/$config.yml.example config/$config.yml; done

	#		customizing database.yml
	cd $CANVASDIR/config
	touch mydatabase.yml
	chown -R $CANVASUSER:$CANVASUSER mydatabase.yml

read -r -d '' database << __EOF__
# do not create a queue: section for your test environment
test:
  adapter: postgresql
  encoding: utf8
  database: canvas_test
  host: localhost
  username: canvas
  timeout: 5000

development:
  adapter: postgresql
  encoding: utf8
  database: canvas_development
  timeout: 5000

production:
  adapter: postgresql
  encoding: utf8
  database: canvas_production
  host: localhost
  username: ${POSTGRESUSER}
  password: ${POSTGRESPASSWD}
  timeout: 5000
__EOF__

	echo -e "${database}" >> mydatabase.yml

	rm -rf database.yml
	mv mydatabase.yml database.yml

	#		customizing pg_hba.conf
	cd $CURRENTPATH
	if [[ -f pg_hba.conf ]]; then
		rm -rf $PGDIR/pg_hba.conf
		cp pg_hba.conf $PGDIR/pg_hba.conf
	else
		echo -e "\t****************** Not exist pg_hba.conf file *********************"
		exit 1
	fi

	touch $TEMPDIR/files.confirm
	echo -e "\t******************* adding necessary files. Success! ***************"
fi

echo -e
echo -e "\t********************* Installing bundle. Finished ********************"
echo -e
####################################################################################


################################ step 10: setup bundle #############################
echo -e
echo -e "\t************************* Setup bundle *******************************"
sleep 3

echo -e
if [[ -f $TEMPDIR/setup.confirm ]]; then
	echo -e "\t******************* Already setup bundle. OK! ************************"
else
	cd $CANVASDIR
	sudo -u $CANVASUSER RAILS_ENV=production $BUNDLEDIR/bundle exec rake db:reset_encryption_key_hash
	sudo -u $CANVASUSER RAILS_ENV=production $BUNDLEDIR/bundle exec rake db:initial_setup
	setupok=$?
	if [[ $setupok -eq 0 ]]; then
		echo -e "\t************************* Setup bundle. Success! **********************"
		touch $TEMPDIR/setup.confirm
	else
		echo -e "\t*********** Setup bundle, failure. You must try it again. *************"
		exit 1
	fi
fi

echo -e
echo -e "\t********************* Setup bundle. Finished *************************"
echo -e
####################################################################################


################################### stepe 11: Installing npm #######################
echo -e
echo -e "\t************************* Installing npm *****************************"
sleep 3

echo -e
cd $CANVASDIR
if [[ -f $TEMPDIR/npm.confirm ]]; then
	echo -e "\t********************* Already installed npm. OK! ********************"
else
	mkdir -p log tmp/pids public/assets public/stylesheets/compiled
	touch Gemfile.lock
	chown -R $CANVASUSER config/environment.rb log tmp public/assets \
		public/stylesheets/compiled Gemfile.lock config.ru

	gem install execjs
	npm install
	npmok=$?
	if [[ $npmok -eq 0 ]]; then
		echo -e "\t************************* installing npm. Success! *******************"
		touch $TEMPDIR/npm.confirm
	else
		echo -e "\t********** installing npm, failure. You must try it again. ***********"
		rm -rf $CANVASDIR/node_modules
		#exit 1		# probably failure due to netwworking load
	fi
fi
echo -e
echo -e "\t********************** Installing npm. Finished **********************"
echo -e
####################################################################################


############################ step 12: compile assets ###############################
echo -e
echo -e "\t*********************** Compiling assets *****************************"
sleep 3

echo -e
cd $CANVASDIR
if [[ -f $TEMPDIR/assets.confirm ]]; then
	echo -e "\t********************** Already compiled assets. OK! *****************"
else
	sudo -u $CANVASUSER RAILS_ENV=production $BUNDLEDIR/bundle exec rake canvas:compile_assets
	assetsok=$?
	if [[ $assetsok -eq 0 ]]; then
		echo -e "\t*********************** compiling assets. Success! ********************"
		touch $TEMPDIR/assets.confirm
	else
		echo -e "\t******** compiling assets, failur. You must try it again. ***********"
		exit 1
	fi
fi

echo -e
echo -e "\t********************** Compiling assets. Finished ********************"
echo -e
####################################################################################


########################## step 13: install passenger package ######################
echo -e
echo -e "\t****************** Installing passenger package **********************"
sleep 3

if [[ -f $TEMPDIR/passenger.confirm ]]; then
	echo -e "\t******************** Already setted conf files. OK! ******************"
else
	cd $CANVASDIR
	chown $CANVASUSER config/*.yml
	chmod 400 config/*.yml
	gem install passenger
	passenger-install-apache2-module
	touch $TEMPDIR/passenger.confirm
	echo -e "\t****************** Installing passenger package. Success! ************"
fi

echo -e
echo -e "\t************** Installing passenger package. Finished ****************"
echo -e
####################################################################################


############################ step 14: set conf files ###############################
echo -e
echo -e "\t************************ Setting conf files ***************************"
sleep 3

echo -e
if [[ -f $TEMPDIR/conf.confirm ]]; then
	echo -e "\t******************* Already setted conf files. OK! *******************"
else
	read -r -d '' http << __EOF__

LoadModule passenger_module /usr/local/lib/ruby/gems/2.3.0/gems/passenger-5.1.2/buildout/apache2/mod_passenger.so

<VirtualHost *:80>
    ServerName $(hostname -I)
    ServerAlias $(hostname -I)
    DocumentRoot /var/rails/canvas/public
    ErrorLog /var/log/httpd/canvas_errors.log
    LogLevel warn
    CustomLog /var/log/httpd/canvas_access.log combined
    SetEnv RAILS_ENV production
    <Directory /var/rails/canvas/public>
	Allow from all
        Options -MultiViews
	Options FollowSymLinks
	AllowOverride None
	Require all granted
    </Directory>
</VirtualHost>
__EOF__

echo "${http}" >> $HTTPDIR/httpd.conf

read -r -d '' passenger << __EOF__
# http://www.modrails.com/documentation/Users%20guide%20Apache.html#_configuring_phusion_passenger
PassengerRoot /usr/local/lib/ruby/gems/2.3.0/gems/passenger-5.1.2
PassengerDefaultRuby /usr/local/bin/ruby
PassengerDefaultUser ${CANVASUSER}

# enable "high performance mode" which is incompatible with some apache modules
# such as mod_rewrite -- we don't think we need those, so this takes some load off httpd for each request
PassengerHighPerformance on

# Increase the log-level a bit while we get familiar with Passenger
PassengerLogLevel 1

# Set idle timeouts to 0 so that all Rails apps stick around
RailsAppSpawnerIdleTime 0
RailsFrameworkSpawnerIdleTime 0
PassengerPoolIdleTime 0

# Related: Minimum/maximum number of instances to start *once the application has been accessed*
PassengerMaxPoolSize 10

# Settings below here are only supported on Passenger 3.0 and above
PassengerMinInstances 2

# PreStart URLs. Passenger will "ping" this/these URL(s) to invoke the apps when Apache starts
# (note, Passenger internally replaces the host part of the URL with 'localhost', but the URL must match the VirtualHost)
PassengerPreStart $(hostname -I)

__EOF__

	touch passenger.conf
	echo "${passenger}" >> passenger.conf
	mv passenger.conf $PASSENGERDIR/passenger.conf

	touch $TEMPDIR/conf.confirm
	echo -e "\t******************** Setting conf files. Success! *********************"
fi

echo -e
echo -e "\t****************** Setting conf files. Finished ***********************"
echo -e
####################################################################################


########################## step 15: start canvas ###################################
echo -e
echo -e "\t************************* Starting canvas ****************************"
sleep 3

ln -s /var/rails/canvas/script/canvas_init /etc/init.d/canvas_init

systemctl start httpd
systemctl enable httpd

firewall-cmd --add-service=http --permanent > /dev/null 2>&1
firewall-cmd --reload > /dev/null 2>&1

/etc/init.d/canvas_init start

sleep 3

exit 0
